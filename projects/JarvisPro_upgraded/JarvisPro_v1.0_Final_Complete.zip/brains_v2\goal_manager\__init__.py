"""
BrainV2 Goal Manager — Manages goal state within BrainV2 planning pipeline.

Coordinates with the main GoalsManager for cross-manager goal tracking.
"""

from .base import BrainGoal, GoalState, GoalManager
from .lifecycle import create_goal, update_goal_state, advance_goal

__all__ = [
    'BrainGoal', 'GoalState', 'GoalManager',
    'create_goal', 'update_goal_state', 'advance_goal',
]
