"""
BrainV2 Learning — Experience-based learning and self-improvement.

Provides:
- Experience extraction and storage
- Pattern detection from command history
- Learning from success/failure
- Strategy adjustment
- Knowledge graph updates
"""

from .engine import LearningEngine, get_learning_engine
from .experience import Experience, ExperienceType, ExperienceStore
from .patterns import PatternDetector, Pattern, PatternType

__all__ = [
    'LearningEngine', 'get_learning_engine',
    'Experience', 'ExperienceType', 'ExperienceStore',
    'PatternDetector', 'Pattern', 'PatternType',
]
